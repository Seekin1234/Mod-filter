package com.example.pickupfilter.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class PickupFilterScreen extends Screen {
    private record Entry(Item item, Identifier key, String name) {}

    private static List<Entry> ALL;

    private static List<Entry> all() {
        if (ALL == null) {
            ALL = BuiltInRegistries.ITEM.stream()
                    .filter(i -> i != Items.AIR)
                    .map(i -> new Entry(i, BuiltInRegistries.ITEM.getKey(i),
                            new ItemStack(i).getHoverName().getString()))
                    .sorted(Comparator.comparing(Entry::name, String.CASE_INSENSITIVE_ORDER))
                    .toList();
        }
        return ALL;
    }

    private static final int ROW_H = 22;
    private static final int LIST_TOP = 80;

    private final ClientConfig config = ClientConfig.get();
    private final List<Button> rows = new ArrayList<>();
    private String searchText = "";
    private int page = 0;
    private int perPage = 5;
    private int left;
    private int w;

    private EditBox search;
    private Button allButton, prev, next, pageInfo;

    public PickupFilterScreen() {
        super(Component.translatable("pickupfilter.title"));
    }

    @Override
    protected void init() {
        w = 260;
        left = this.width / 2 - w / 2;
        perPage = Math.max(1, (this.height - 56 - LIST_TOP) / ROW_H);

        addRenderableWidget(new StringWidget(left, 10, w, 12, this.title, this.font).alignCenter());

        search = new EditBox(this.font, left, 28, w, 20, Component.translatable("pickupfilter.search"));
        search.setHint(Component.translatable("pickupfilter.search"));
        search.setValue(searchText);
        search.setResponder(s -> { searchText = s; page = 0; refreshRows(); });
        addRenderableWidget(search);

        allButton = Button.builder(allLabel(), b -> {
            config.pickupAll = !config.pickupAll;
            b.setMessage(allLabel());
            refreshRows();
        }).bounds(left, 52, w, 20).build();
        addRenderableWidget(allButton);

        int y = this.height - 52;
        prev = Button.builder(Component.literal("<"), b -> { page--; refreshRows(); })
                .bounds(left, y, 40, 20).build();
        next = Button.builder(Component.literal(">"), b -> { page++; refreshRows(); })
                .bounds(left + w - 40, y, 40, 20).build();
        pageInfo = Button.builder(Component.literal("1/1"), b -> {})
                .bounds(left + 44, y, w - 88, 20).build();
        pageInfo.active = false;
        addRenderableWidget(prev);
        addRenderableWidget(next);
        addRenderableWidget(pageInfo);

        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(left, this.height - 28, w, 20).build());

        rows.clear();
        refreshRows();
    }

    private Component allLabel() {
        return Component.translatable(config.pickupAll ? "pickupfilter.all.on" : "pickupfilter.all.off");
    }

    private List<Entry> filtered() {
        String q = searchText.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return all();
        return all().stream()
                .filter(e -> e.name().toLowerCase(Locale.ROOT).contains(q) || e.key().toString().contains(q))
                .toList();
    }

    private Component rowLabel(Entry e) {
        boolean on = config.items.contains(e.key().toString());
        return Component.literal((on ? "[x] " : "[  ] ") + e.name());
    }

    private void refreshRows() {
        rows.forEach(this::removeWidget);
        rows.clear();

        List<Entry> list = filtered();
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pages - 1));

        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx >= list.size()) break;
            Entry e = list.get(idx);
            Button b = Button.builder(rowLabel(e), btn -> {
                String id = e.key().toString();
                if (!config.items.remove(id)) config.items.add(id);
                btn.setMessage(rowLabel(e));
            }).bounds(left, LIST_TOP + i * ROW_H, w, 20).build();
            b.active = !config.pickupAll;   // list is only used when "pick up everything" is OFF
            rows.add(b);
            addRenderableWidget(b);
        }

        prev.active = page > 0;
        next.active = page < pages - 1;
        pageInfo.setMessage(Component.literal((page + 1) + " / " + pages));
    }

    @Override
    public void onClose() {
        config.save();
        PickupFilterClient.sync();
        super.onClose();
    }
}
