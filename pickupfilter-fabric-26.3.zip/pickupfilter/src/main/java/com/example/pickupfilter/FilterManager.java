package com.example.pickupfilter;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Server-side store of each player's pickup filter (in memory; the client re-sends it on join). */
public final class FilterManager {
    private record PlayerFilter(boolean pickupAll, Set<Identifier> items) {}

    private static final Map<UUID, PlayerFilter> FILTERS = new ConcurrentHashMap<>();

    private FilterManager() {}

    public static void set(UUID player, FilterSyncPayload payload) {
        FILTERS.put(player, new PlayerFilter(payload.pickupAll(), new HashSet<>(payload.items())));
    }

    public static void remove(UUID player) {
        FILTERS.remove(player);
    }

    /** No filter on record, or "pick up everything" on -> allow. Otherwise only selected items. */
    public static boolean allows(Player player, ItemStack stack) {
        PlayerFilter filter = FILTERS.get(player.getUUID());
        if (filter == null || filter.pickupAll()) return true;
        return filter.items().contains(BuiltInRegistries.ITEM.getKey(stack.getItem()));
    }
}
