package com.example.pickupfilter.client;

import com.example.pickupfilter.FilterSyncPayload;
import com.example.pickupfilter.PickupFilterMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.resources.Identifier;

public final class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pickupfilter.json");
    private static ClientConfig instance;

    /** true = pick up everything (default). false = only the items in {@link #items}. */
    public boolean pickupAll = true;
    public Set<String> items = new TreeSet<>();

    public static ClientConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static ClientConfig load() {
        try {
            if (Files.exists(FILE)) {
                ClientConfig c = GSON.fromJson(Files.readString(FILE), ClientConfig.class);
                if (c != null && c.items != null) return c;
            }
        } catch (Exception e) {
            PickupFilterMod.LOGGER.warn("Could not read pickupfilter.json, using defaults", e);
        }
        return new ClientConfig();
    }

    public void save() {
        try {
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            PickupFilterMod.LOGGER.warn("Could not save pickupfilter.json", e);
        }
    }

    public FilterSyncPayload toPayload() {
        return new FilterSyncPayload(pickupAll,
                items.stream().map(Identifier::tryParse).filter(Objects::nonNull).toList());
    }
}
