package com.example.pickupfilter;

import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record FilterSyncPayload(boolean pickupAll, List<Identifier> items) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<FilterSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(PickupFilterMod.MOD_ID, "sync"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FilterSyncPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, FilterSyncPayload::pickupAll,
            Identifier.STREAM_CODEC.apply(ByteBufCodecs.list(4096)), FilterSyncPayload::items,
            FilterSyncPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
