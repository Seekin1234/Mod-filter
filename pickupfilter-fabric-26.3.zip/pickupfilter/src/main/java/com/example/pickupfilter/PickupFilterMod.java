package com.example.pickupfilter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PickupFilterMod implements ModInitializer {
    public static final String MOD_ID = "pickupfilter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Client -> Server: the player's filter settings
        PayloadTypeRegistry.playC2S().register(FilterSyncPayload.TYPE, FilterSyncPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(FilterSyncPayload.TYPE,
                (payload, context) -> FilterManager.set(context.player().getUUID(), payload));

        ServerPlayConnectionEvents.DISCONNECT.register(
                (handler, server) -> FilterManager.remove(handler.getPlayer().getUUID()));
    }
}
