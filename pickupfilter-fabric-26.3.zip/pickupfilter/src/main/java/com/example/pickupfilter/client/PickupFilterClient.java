package com.example.pickupfilter.client;

import com.example.pickupfilter.FilterSyncPayload;
import com.example.pickupfilter.PickupFilterMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class PickupFilterClient implements ClientModInitializer {
    private static KeyMapping openKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category =
                KeyMapping.Category.register(Identifier.fromNamespaceAndPath(PickupFilterMod.MOD_ID, "main"));
        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.pickupfilter.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_P, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.consumeClick()) {
                if (mc.screen == null && mc.player != null) {
                    mc.setScreen(new PickupFilterScreen());
                }
            }
        });

        // Send saved settings to the server every time we join a world/server
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> sync());
    }

    public static void sync() {
        if (ClientPlayNetworking.canSend(FilterSyncPayload.TYPE)) {
            ClientPlayNetworking.send(ClientConfig.get().toPayload());
        }
    }
}
